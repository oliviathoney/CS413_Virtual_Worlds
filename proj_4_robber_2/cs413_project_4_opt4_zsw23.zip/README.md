#	Project	4
##	Bank Heist (Sequel to Bank project 3)
*	Olivia Thoney (opt4)
*	Zachary Wilson-Long (zsw23)  
##	Instructions
<b>Level 1:</b> Character automatically moves to the right, you control up and down movement along 3 different paths to avoid obsticles and reach the getaway vehicle.

<b>Level 2:</b> You control up and down movement as in level 1 however now you can use left and right to change the speed of your car and attempt to reach the end of the road.

<b>Level 3:</b> You move your character left and right and then use space to jump up the building until you reach the illuminated window to win.
##	Known	Bugs	or	Issues
Layering of objects can be a little weird, sometimes.
The robber sprites on level 3 can be a bit janky.
##	Credits
*	OLIVIA: Majority of level 3, sequence animations, UI design (help pages, intro etc.), pathing, and level change events.
*	ZACH: Majority of level 2, new spritework, animated vehicles, sound design (all sounds were my voice and audacity).
